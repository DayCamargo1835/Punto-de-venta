// src/components/Layout.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';
import "../styles/Layout.css";

const Layout = ({ children }) => {
  const navigate = useNavigate();
  const username = localStorage.getItem("username") || "Usuario";

  const handleLogout = () => {
    localStorage.clear();
    navigate("/login");
  };

  return (
    <div className="layout-container">
      <header className="admin-header">
        <h2>Bienvenido, {username}</h2>
      </header>

      <main className="layout-content">
        {children}
      </main>

      <footer className="admin-footer">
      <div className="navigation-buttons-compact">
          <button className="btn-nav-small" onClick={() => navigate(-1)}>⏪ Regresar</button>
          <button className="btn-nav-small" onClick={() => navigate("/admin-dashboard")}>🏠 Menú</button>
        </div>
        <button className="menu-logout-button" onClick={handleLogout}>Cerrar sesión</button>
      </footer>
    </div>
  );
};

export default Layout;
